ThanhGhi.o: ../ThanhGhi.cpp ../ThanhGhi.h ../FF_D.h

../ThanhGhi.h:

../FF_D.h:
