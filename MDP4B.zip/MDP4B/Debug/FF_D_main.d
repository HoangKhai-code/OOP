FF_D_main.o: ../FF_D_main.cpp ../ThanhGhi.h ../FF_D.h

../ThanhGhi.h:

../FF_D.h:
