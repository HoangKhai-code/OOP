################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../FF_D.cpp \
../FF_D_main.cpp \
../ThanhGhi.cpp 

OBJS += \
./FF_D.o \
./FF_D_main.o \
./ThanhGhi.o 

CPP_DEPS += \
./FF_D.d \
./FF_D_main.d \
./ThanhGhi.d 


# Each subdirectory must supply rules for building sources it contributes
%.o: ../%.cpp subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GCC C++ Compiler'
	g++ -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


