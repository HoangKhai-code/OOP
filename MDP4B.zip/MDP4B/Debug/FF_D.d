FF_D.o: ../FF_D.cpp ../FF_D.h

../FF_D.h:
