#include <iostream>
#include "ThanhGhi.h"
using namespace std;

ThanhGhi::ThanhGhi() {}

void ThanhGhi::XungClock(int D) {
    // dich phai
    int q3 = ff[3].getQ();
    int q2 = ff[2].getQ();
    int q1 = ff[1].getQ();

    ff[0].clock(q1);
    ff[1].clock(q2);
    ff[2].clock(q3);
    ff[3].clock(D);
}
void ThanhGhi::reset() {
    for (int i = 0; i < 4; ++i) {
        ff[i].reset();  // reset toan bo FF_D
}
}

void ThanhGhi::hienthi(){
    cout << "Q3 Q2 Q1 Q0 = "<< ff[3].getQ() << " "<< ff[2].getQ() << " "<< ff[1].getQ() << " "<< ff[0].getQ() << endl;
}
