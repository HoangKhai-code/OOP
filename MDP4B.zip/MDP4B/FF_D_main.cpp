#include <iostream>
#include "ThanhGhi.h"
using namespace std;
int main() {
    FF_D bst;
    ThanhGhi tg;
    int D=0;         // du lieu mac dinh luc dau
    char luachon;
    cout << "===MẠCH DỊCH PHẢI 4 BIT-B2308304===\n";
    while (1) { //cho lap vo han
        bst.bangsuthat();
        cout << "\n*Dữ liệu hiện tại D = " << D << "\n";
        cout << "Q3 Q2 Q1 Q0 hiện tại: ";
        tg.hienthi();
        cout << "1. Bấm xung CLOCK\n";
        cout << "2. Clear = 0\n";
        cout << "3. Nhập dữ liệu đầu vào D (0 hoặc 1)\n";
        cout << "Chọn thao tác: ";
        cin >> luachon;
        if (luachon == '1') {
            tg.XungClock(D);
            cout << "*Đã bấm xung clock. Dữ liệu dịch phải.\n";
        }
        else if (luachon == '2') {
            tg.reset();
            cout << "*Đã RESET.\n";
        }
        else if (luachon == '3') {
            cout << "*Nhập D (0 hoặc 1): ";
            cin >> D;
            if (D != 0 && D != 1) {
                cout << "*Chỉ được nhập 0 hoặc 1! D giữ nguyên.\n";
            }
        } else {
            cout << "*Lựa chọn không hợp lệ.\n";
        }
    }
    return 0;
}
