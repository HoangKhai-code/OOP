#ifndef THANHGHI_H_
#define THANHGHI_H_

#include "FF_D.h"

class ThanhGhi {
private:
    FF_D ff[4];  // 4 Flip-Flop D

public:
    ThanhGhi();
    void XungClock(int D);   // nhan D roi dich phai toan bo
    void reset();             // Reset
    void hienthi();             // In Q3 Q2 Q1 Q0 hien tai
};

#endif /* THANHGHI_H_ */
