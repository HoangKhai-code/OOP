#include <iostream>
#include "FF_D.h"
using namespace std;

FF_D::FF_D() {
    Q = 0;
}
void FF_D::clock(int D) {
    Q = D;
}
int FF_D::getQ() const {
    return Q;
}
void FF_D::reset() {
    Q = 0;
}
void FF_D::bangsuthat(){
    cout<< "          BẢNG SỰ THẬT\n";
        cout<< "====Input===============Output====\n";
        cout<< "   Cl|Ck|D|          Q3|Q2|Q1|Q0\n";
        cout<< "    0|x |x|           0| 0|0 |0\n";
        cout<< "    1|⬆ |1|           1| 0|0 |0\n";
        cout<< "    1|⬆ |1|           1| 1|0 |0\n";
        cout<< "    1|⬆ |1|           1| 1|1 |0\n";
        cout<< "    1|⬆ |0|           0| 1|1 |1\n";
        cout<< "    1|⬆ |0|           0| 0|1 |1\n";
        cout<< "    1|⬆ |1|           1| 0|0 |1\n";
        cout<< "    1|⬆ |0|           0| 1|0 |0";
}
