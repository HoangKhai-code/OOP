#ifndef FF_D_H
#define FF_D_H
class FF_D {
private:
    int Q;
public:
    FF_D();
    void clock(int D);  // Nhan D khi co clock
    int getQ() const;   // lay Q hien tai
    void reset();        // reset
    void bangsuthat();
};
#endif

