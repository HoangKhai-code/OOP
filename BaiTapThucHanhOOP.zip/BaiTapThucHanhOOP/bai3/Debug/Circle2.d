Circle2.o: ../Circle2.cpp ../Circle2.h

../Circle2.h:
