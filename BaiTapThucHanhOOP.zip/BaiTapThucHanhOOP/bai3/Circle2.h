/*
 * Circle2.h
 *
 *  Created on: Jul 7, 2025
 *      Author: user
 */

#ifndef CIRCLE2_H_
#define CIRCLE2_H_


class Circle2 {
// member data
private:
double r;
// member functions
public:
Circle2();
Circle2(double r);
void setRadius(double r);
double getRadius(void);
double calcArea(void);
double calcCirc(void);
void printPointer(void);
};


#endif /* CIRCLE2_H_ */
