#ifndef SWTIMER_H_
#define SWTIMER_H_

class SWTime {
private:
int hundreths;
int seconds;
int minutes;
int hours;

public:
SWTime();
void clearTime(void);
void incTime(int h, int m, int s, int hu);
int getHours();
int getMinutes();
int getSeconds();
int getHundreths();
};
#endif /* SWTIMER_H_ */
