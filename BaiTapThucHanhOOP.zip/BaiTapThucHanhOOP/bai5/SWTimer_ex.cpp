#include <iostream>
#include "StopWatch.h"
using namespace std;

int main(void)
{
    StopWatch sw1;
    cout << "Start stopwatch...\n";
    sw1.start();

    for (int i = 0; i < 123; ++i) {
        sw1.tick();
    }
    cout << "Stop stopwatch...\n";
    sw1.stop();

    SWTime total = sw1.getTime();
    cout << "Current stopwatch time: "
         << total.getHours() << ":"
         << total.getMinutes() << ":"
         << total.getSeconds() << "."
         << total.getHundreths() << endl;
    sw1.start();
    for (int i = 0; i < 87; ++i) {
        sw1.tick();
    }
    sw1.stop();
    SWTime lap = sw1.getLap();
    cout << "Lap time: "
         << lap.getHours() << ":"
         << lap.getMinutes() << ":"
         << lap.getSeconds() << "."
         << lap.getHundreths() << endl;

    system("pause");
    return 0;
}
