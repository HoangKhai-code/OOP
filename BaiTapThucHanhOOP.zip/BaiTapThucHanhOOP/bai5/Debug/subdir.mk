################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../SWTimer.cpp \
../SWTimer_ex.cpp \
../StopWatch.cpp 

OBJS += \
./SWTimer.o \
./SWTimer_ex.o \
./StopWatch.o 

CPP_DEPS += \
./SWTimer.d \
./SWTimer_ex.d \
./StopWatch.d 


# Each subdirectory must supply rules for building sources it contributes
%.o: ../%.cpp subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GCC C++ Compiler'
	g++ -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


