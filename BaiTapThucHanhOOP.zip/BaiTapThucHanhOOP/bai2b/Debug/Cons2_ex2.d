Cons2_ex2.o: ../Cons2_ex2.cpp ../Cons2.h

../Cons2.h:
