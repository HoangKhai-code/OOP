Cons2.o: ../Cons2.cpp ../Cons2.h

../Cons2.h:
