#ifndef CONS2_H_
#define CONS2_H_

class Cons2{

private:
double var1;

public:
Cons2(double v1);
Cons2(void);
void setVar1(double v1);
double getVar1(void);
};
#endif /* CONS2_H_ */
