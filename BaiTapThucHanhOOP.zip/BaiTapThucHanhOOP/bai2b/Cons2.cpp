#include "Cons2.h"
#include <iostream>
#include <cstdlib>
using namespace std;

Cons2::Cons2(double v1){
var1 = v1;
cout << "Created object of type Cons with value " << var1 << "\n";
}
Cons2::Cons2(void){
var1 = 0.0;
cout << "Created object of type Cons\n";
}
void Cons2::setVar1(double v1){
var1 = v1;
}
double Cons2::getVar1(){
return var1;
}
