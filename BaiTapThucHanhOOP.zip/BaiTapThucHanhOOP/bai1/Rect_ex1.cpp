#include <iostream>
#include "rectangle.h"
using namespace std;

int main(void){
    Rectangle rect1;
    double w;
    double l;
     cout<<"nhap chieu rong cua hinh chu nhat : ";
     cin>>w;
     rect1.setWidth(w);
     cout<<"nhap chieu dai cua hinh chu nhat : ";
     cin>>l;
     rect1.setLength(l);
     cout<<"cac thong so cua hinh chu nhat la: \n";
     cout<<"rong = "<< rect1.getWidth()<<endl;
     cout<<"dai = "<< rect1.getLength()<<endl;
     cout<< "dien tich = "<< rect1.getArea()<<endl;
     system("pause");
     return 0;
}
