#include "rectangle.h"
#include <iostream>
#include <cstdlib>
using namespace std;

void Rectangle::setWidth(double w){
    if (w>0) width =w;
    else {
        cout<< "invalid input\n";
        exit(EXIT_FAILURE);
    }
}
void Rectangle::setLength(double l){
    if (l>0) length =l;
    else {
        cout<< "invalid input\n";
        exit(EXIT_FAILURE);
    }
}
double Rectangle::getWidth(){
    return width;
}
double Rectangle::getLength(){
    return length;
}
double Rectangle::getArea(){
    return width * length;
}
