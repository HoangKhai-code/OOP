Rect_ex1.o: ../Rect_ex1.cpp ../rectangle.h

../rectangle.h:
