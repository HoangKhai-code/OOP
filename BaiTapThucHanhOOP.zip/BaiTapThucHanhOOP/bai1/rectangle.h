
#ifndef RECTANGLE_H_
#define RECTANGLE_H_

class Rectangle{
private:
    double width;
    double length;
public:
    void setWidth(double w);
    void setLength(double l);
    double getWidth(void);
    double getLength(void);
    double getArea(void);
};

#endif /* RECTANGLE_H_ */
