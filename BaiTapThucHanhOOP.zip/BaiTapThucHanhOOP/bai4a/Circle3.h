#ifndef CIRCLE3_H_
#define CIRCLE3_H_

class Circle3 {

private:
double r;
public:
static int circle_cnt;

public:
Circle3();
void setRadius(double r);
double getRadius(void);
};
#endif /* CIRCLE3_H_ */
