Stactic_ex.o: ../Stactic_ex.cpp ../Circle3.h

../Circle3.h:
