Isosceles_Triangle.o: ../Isosceles_Triangle.cpp ../Isosceles_Triangle.h \
 ../Triangle.h

../Isosceles_Triangle.h:

../Triangle.h:
