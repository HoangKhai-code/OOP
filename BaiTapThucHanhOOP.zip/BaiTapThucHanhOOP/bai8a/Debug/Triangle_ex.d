Triangle_ex.o: ../Triangle_ex.cpp ../Right_Triangle.h ../Triangle.h \
 ../Isosceles_Triangle.h

../Right_Triangle.h:

../Triangle.h:

../Isosceles_Triangle.h:
