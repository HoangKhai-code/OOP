################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../Isosceles_Triangle.cpp \
../Right_Triangle.cpp \
../Triangle.cpp \
../Triangle_ex.cpp 

OBJS += \
./Isosceles_Triangle.o \
./Right_Triangle.o \
./Triangle.o \
./Triangle_ex.o 

CPP_DEPS += \
./Isosceles_Triangle.d \
./Right_Triangle.d \
./Triangle.d \
./Triangle_ex.d 


# Each subdirectory must supply rules for building sources it contributes
%.o: ../%.cpp subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GCC C++ Compiler'
	g++ -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


