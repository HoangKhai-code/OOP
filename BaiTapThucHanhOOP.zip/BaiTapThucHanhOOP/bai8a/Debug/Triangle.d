Triangle.o: ../Triangle.cpp ../Triangle.h

../Triangle.h:
