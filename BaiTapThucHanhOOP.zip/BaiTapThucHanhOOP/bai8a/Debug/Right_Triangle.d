Right_Triangle.o: ../Right_Triangle.cpp ../Right_Triangle.h ../Triangle.h

../Right_Triangle.h:

../Triangle.h:
