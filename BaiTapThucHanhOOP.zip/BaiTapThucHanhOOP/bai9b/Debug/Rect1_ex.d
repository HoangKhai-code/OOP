Rect1_ex.o: ../Rect1_ex.cpp ../Rect1.h

../Rect1.h:
