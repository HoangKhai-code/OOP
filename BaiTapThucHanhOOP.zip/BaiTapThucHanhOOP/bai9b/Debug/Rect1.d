Rect1.o: ../Rect1.cpp ../Rect1.h

../Rect1.h:
