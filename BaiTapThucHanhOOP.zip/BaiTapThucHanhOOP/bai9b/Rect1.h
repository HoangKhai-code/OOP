#ifndef RECT1_H_
#define RECT1_H_
class Rect1 {
private:
double width;
double length;
public:
// Exceptions
class NegativeDimension{
// empty class for exceptions
};
// Constructor
Rect1();
// Setters
void setWidth(double w);
void setLength(double l);
// getters
double getWidth(void);
double getLength(void);
// calculations
double calcArea(void);
};
#endif /* RECT1_H_ */
