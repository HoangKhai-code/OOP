myvect_ex.o: ../myvect_ex.cpp ../myvect.h

../myvect.h:
