#include "Des.h"
#include <iostream>
#include <cstdlib>
using namespace std;
Des::Des(void){
var1 = 0.0;
cout << "Created object of type Des\n ";
}
Des::~Des(void){
cout << " Object of type Des destroyed\n";
}
void Des::setVar1(double v1){
var1 = v1;
}
double Des::getVar1(){
return var1;
}
