#ifndef DES_H_
#define DES_H_

class Des{

private:
double var1;

public:
Des(void);
~Des(void);
void setVar1(double v1);
double getVar1(void);
};
#endif /* DES_H_ */
