#ifndef CIRCLE4_H_
#define CIRCLE4_H_
class Circle4 {

private:
double r;
public:
static int circle_cnt4;

public:
Circle4();
void setRadius(double r);
double getRadius(void);
static int getCnt(void);
};
#endif /* CIRCLE4_H_ */
