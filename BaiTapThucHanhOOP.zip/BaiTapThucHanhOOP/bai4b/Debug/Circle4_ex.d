Circle4_ex.o: ../Circle4_ex.cpp ../Circle4.h

../Circle4.h:
