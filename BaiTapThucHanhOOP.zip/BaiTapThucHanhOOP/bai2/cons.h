

#ifndef CONS_H_
#define CONS_H_

class Cons{
private:
    double var1;
public:
    Cons(void);
    void setVar1(double v1);
    double getVar1(void);
};

#endif /* CONS_H_ */
