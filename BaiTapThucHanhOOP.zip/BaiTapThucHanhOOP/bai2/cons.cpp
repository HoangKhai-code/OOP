#include <iostream>
#include "cons.h"
#include <cstdlib>
using namespace std;

Cons::Cons(void){
    var1=0.0;
    cout<<"Created object of type cons\n";
}
void Cons::setVar1(double v1){
    var1=v1;
}
double Cons::getVar1(){
    return var1;
}
