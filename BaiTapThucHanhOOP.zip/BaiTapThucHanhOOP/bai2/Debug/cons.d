cons.o: ../cons.cpp ../cons.h

../cons.h:
