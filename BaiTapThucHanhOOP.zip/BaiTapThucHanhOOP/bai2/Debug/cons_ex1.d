cons_ex1.o: ../cons_ex1.cpp ../cons.h

../cons.h:
