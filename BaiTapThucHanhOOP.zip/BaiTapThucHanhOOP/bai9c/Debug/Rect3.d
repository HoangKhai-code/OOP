Rect3.o: ../Rect3.cpp ../Rect3.h

../Rect3.h:
