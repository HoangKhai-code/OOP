Rect3_ex.o: ../Rect3_ex.cpp ../Rect3.h

../Rect3.h:
