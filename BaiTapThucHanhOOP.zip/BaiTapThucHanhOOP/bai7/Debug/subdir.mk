################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../CircleF.cpp \
../RectangleF.cpp \
../RectangleF_ex.cpp 

OBJS += \
./CircleF.o \
./RectangleF.o \
./RectangleF_ex.o 

CPP_DEPS += \
./CircleF.d \
./RectangleF.d \
./RectangleF_ex.d 


# Each subdirectory must supply rules for building sources it contributes
%.o: ../%.cpp subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GCC C++ Compiler'
	g++ -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


