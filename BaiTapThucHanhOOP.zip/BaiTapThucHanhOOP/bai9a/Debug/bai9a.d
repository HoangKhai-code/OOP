bai9a.o: ../bai9a.cpp
